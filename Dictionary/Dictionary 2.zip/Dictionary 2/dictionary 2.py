from PySide6.QtWidgets import QWidget, QListWidgetItem, QApplication
import json

from widget import Ui_Dictionary2
from cart import Cart


class Lugat(QWidget, Ui_Dictionary2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.listWidget.setFixedHeight(400)
        self.itemlarni_chiqarish()

        self.listWidget.itemSelectionChanged.connect(self.selection_item)
        self.pushButton_4.clicked.connect(self.edit_clicked)
        self.pushButton_3.clicked.connect(self.add_clicked)
        self.pushButton_2.clicked.connect(self.delete_clicked)

    def delete_clicked(self):
        bosigandagi_item = self.listWidget.currentItem()
        self.listWidget.clearFocus()

    def add_clicked(self):
        item = QListWidgetItem()
        widget = Cart()
        widget.label.setText(self.lineEdit_2.text())
        widget.label_2.setText(self.textEdit.toPlainText())
        self.listWidget.addItem(item)
        item.setSizeHint(widget.sizeHint())

        # itemga widgetni o'rmnatish
        self.listWidget.setItemWidget(item, widget)
        self.data[self.lineEdit_2.text()] = self.textEdit.toPlainText()
        self.write_json()
        self.textEdit.clear()
        self.lineEdit_2.clear()

    def edit_clicked(self):
        item = self.listWidget.currentItem()
        widget: Cart = self.listWidget.itemWidget(item)
        widget.label.setText(self.lineEdit_2.text())
        widget.label_2.setText(self.textEdit.toPlainText())

        self.textEdit.clear()
        self.lineEdit_2.clear()

    def itemlarni_chiqarish(self):

        # widget.setFixedWidth(200)

        file = open("..//data.json", 'r')
        self.data = json.load(file)
        item_soni = 0
        for key in self.data.keys():
            item = QListWidgetItem()
            # widgetni yasash
            widget = Cart()
            widget.label_2.setWordWrap(True)
            widget.label.setText(key)
            widget.label_2.setText(f"{self.data[key][:100]}..." if len(self.data[key]) > 100 else self.data[key])
            if item_soni > 20:
                break
            item_soni += 1
            # item qo'shish
            self.listWidget.addItem(item)
            item.setSizeHint(widget.sizeHint())

            # itemga widgetni o'rmnatish
            self.listWidget.setItemWidget(item, widget)

    def selection_item(self):
        item = self.listWidget.currentItem()
        widget = self.listWidget.itemWidget(item)
        title = widget.label.text()
        tarifi = widget.label_2.text()
        self.lineEdit_2.setText(title)
        self.textEdit.setText(tarifi)
        # self.data[self.lineEdit_2.text()] = self.textEdit.toPlainText()
        # self.write_json()

        self.listWidget.addItem(item)
        item.setSizeHint(widget.sizeHint())
        self.listWidget.setItemWidget(item, widget)

    def write_json(self):
        self.data[self.lineEdit_2.text()] = self.textEdit.toPlainText()
        file = open("data.json", 'w')
        json.dump(self.data, file)


app = QApplication()
window = Lugat()
window.show()
app.exec()
